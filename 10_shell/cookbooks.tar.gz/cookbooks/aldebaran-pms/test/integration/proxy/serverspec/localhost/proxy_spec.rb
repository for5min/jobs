require 'spec_helper'

describe 'PMS application with Proxy' do
  describe file('/opt/newrelic/newrelic.yml') do
    its(:content) { should match(/^\s+proxy_host: proxy\.example\.com$/) }
    its(:content) { should match(/^\s+proxy_port: 10080$/) }
  end
end
