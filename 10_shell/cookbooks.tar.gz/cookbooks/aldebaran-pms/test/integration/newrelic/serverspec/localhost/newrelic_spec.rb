require 'spec_helper'

describe file('/etc/supervisor.d/pms-81.conf') do
  it { should exist }
  it { should be_file }
  its(:content) { should contain '-javaagent:/opt/newrelic/newrelic.jar' }
end

describe file('/etc/supervisor.d/pms-82.conf') do
  it { should exist }
  it { should be_file }
  its(:content) { should contain '-javaagent:/opt/newrelic/newrelic.jar' }
end
