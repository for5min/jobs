require 'spec_helper'

describe file('/opt/pms/pms-81') do
  it { should exist }
  it { should be_directory }
end

describe file('/opt/pms/pms-82') do
  it { should exist }
  it { should be_directory }
end

describe file('/opt/pms/pms-81/current') do
  it { should exist }
  it { should be_symlink }
end

describe file('/opt/pms/pms-82/current') do
  it { should exist }
  it { should be_symlink }
end

describe file('/opt/pms/pms-81/current/config') do
  it { should exist }
  it { should be_directory }
end

describe file('/opt/pms/pms-82/current/config') do
  it { should exist }
  it { should be_directory }
end

describe file('/opt/pms/pms-81/current/config/app.yaml') do
  it { should exist }
  it { should be_file }
  its(:content_as_yaml) { should include('server' => include('port' => '8081')) }
  its(:content_as_yaml) { should include('cassandra' => include('keyspace' => 'pms_core')) }
  its(:content_as_yaml) { should include('rabbitmq' => include('host' => 'localhost')) }
  its(:content_as_yaml) { should include('cassandra' => include('username' => 'pms_api_user', 'password' => 'x034ndf923')) }
end

describe file('/opt/pms/pms-82/current/config/app.yaml') do
  it { should exist }
  it { should be_file }
  its(:content_as_yaml) { should include('server' => include('port' => '8082')) }
  its(:content_as_yaml) { should include('cassandra' => include('keyspace' => 'pms_core')) }
  its(:content_as_yaml) { should include('rabbitmq' => include('host' => 'localhost')) }
  its(:content_as_yaml) { should include('cassandra' => include('username' => 'pms_api_user', 'password' => 'x034ndf923')) }
end

describe file('/opt/pms/pms-81/current/config/logback.groovy') do
  it { should exist }
  it { should be_file }
  it { should be_owned_by 'pms' }
  it { should be_grouped_into 'aldebaran' }
end

describe file('/opt/pms/pms-82/current/config/logback.groovy') do
  it { should exist }
  it { should be_file }
  it { should be_owned_by 'pms' }
  it { should be_grouped_into 'aldebaran' }
end

describe file('/etc/supervisor.d/pms-81.conf') do
  it { should exist }
  it { should be_file }
  its(:content) { should contain '-verbose:gc' }
  its(:content) { should contain '--logging.config=/opt/pms/pms-81/' }
  its(:content) { should match %r{ \-jar [^\n]+ \-\-logging\.config=/opt/pms/pms\-} }
end

describe file('/etc/supervisor.d/pms-82.conf') do
  it { should exist }
  it { should be_file }
  its(:content) { should contain '-verbose:gc' }
  its(:content) { should contain '--logging.config=/opt/pms/pms-82/' }
  its(:content) { should match %r{ \-jar [^\n]+ \-\-logging\.config=/opt/pms/pms\-} }
end

describe file('/etc/haproxy/haproxy.cfg') do
  it { should exist }
  it { should be_file }
  it { should be_owned_by 'root' }
  it { should be_grouped_into 'root' }
  it { should be_mode '640' }
  its(:content) { should contain 'listen rabbitmq_5672' }
  its(:content) { should contain 'bind 127.0.0.1:5672' }
end
