name             'aldebaran-pms'
maintainer       'Rakuten, Inc.'
maintainer_email 'ops@rakops.com'
license          'Apache 2.0'
description      'Installs/Configures aldebaran-pms'
long_description 'Installs/Configures aldebaran-pms'
version          '1.0.0'

supports 'ubuntu', '14.04'

depends 'aldebaran-app', '>= 0.6.2'

source_url 'https://github.rakops.com/Chef/aldebaran-pms'
issues_url 'https://github.rakops.com/Chef/aldebaran-pms/issues'
