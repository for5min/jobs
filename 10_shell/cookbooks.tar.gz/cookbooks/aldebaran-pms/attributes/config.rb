#
# Cookbook Name:: aldebaran-pms
# Attributes:: config
#
# Copyright (C) 2017 Rakuten, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

# Cassandra Keyspace
default['aldebaran-pms']['aldebaran-app']['config']['cassandra']['keyspaces'] = {
  'pms' => 'pms_core'
}

default['aldebaran-pms']['aldebaran-app']['config']['cassandra']['reconnection'] = {
  'baseDelay' => 1000,
  'maxDelay' => 60000
}

default['aldebaran-pms']['aldebaran-app']['config']['lock'] = {
  'retries' => {
    'maxAttempts' => 10,
    'backOffInit' => 50,
    'backOffMax' => 1000
  }
}

# Country Default Limits
default['aldebaran-pms']['aldebaran-app']['config']['country'] = {
  'orderRedeemableLimit' => {
    'JPY' => 30000,
    'USD' => 25000,
    'EUR' => 25000,
    'GBP' => 25000,
    'TWD' => 10000,
    'QCD' => 99999
  },
  'monthlyRedeemableLimit' => {
    'JPY' => 100000,
    'USD' => 100000,
    'EUR' => 85000,
    'GBP' => 85000,
    'TWD' => 30000,
    'QCD' => 999999
  }
}

# Expiry Settings
default['aldebaran-pms']['aldebaran-app']['config']['expiry'] = {
  'minimumExpiryDate' => {
    'JPY' => 0,
    'USD' => 3,
    'EUR' => 0,
    'GBP' => 0,
    'TWD' => 3,
    'QCD' => 0
  },
  'maximumExpiryDate' => {
    'JPY' => 365,
    'USD' => 730,
    'EUR' => 365,
    'GBP' => 365,
    'TWD' => 365,
    'QCD' => 999
  }
}

default['aldebaran-pms']['aldebaran-app']['config']['transactionFixTime'] = {
  'JPY' => 93,
  'USD' => 93,
  'EUR' => 62,
  'GBP' => 62,
  'TWD' => 93,
  'QCD' => 99

}

default['aldebaran-pms']['aldebaran-app']['config']['cancelRedeemGrant'] = {
  'termPeriod' => {
    'defaultPeriod' => 180
  }
}

# Auth Filter Settings
default['aldebaran-pms']['aldebaran-app']['config']['auth'] = {
  'threshold' => 10,
  'headername' => 'Authorization',
  'enabled' => true
}

default['aldebaran-pms']['aldebaran-app']['config']['pattern'] = {
  'standard' => {
    'default' => 1
  },
  'term' => {
    'default' => 2
  }
}

# thread that run longer than the threshold will log a WARN.
# the threashold is in millisecond
default['aldebaran-pms']['aldebaran-app']['config']['logging'] = {
  'threadExecutionTimeThresholdMap' => {
    'defaultSyncTask' => 100,
    'defaultAsyncTask' => 50,
    'defaultAsyncManager' => 100
  }
}

default['aldebaran-pms']['aldebaran-app']['config']['futures'] = {
  'listenTimeout' => 30000
}

default['aldebaran-pms']['aldebaran-app']['config']['async'] = {
  'corePoolSize' => 1000,
  'maxPoolSize' => 1000,
  'queueCapacity' => 1000,
  'threadNamePrefix' => 'PmsAsync-'
}

default['aldebaran-pms']['aldebaran-app']['config']['latencyCheck'] = {
  'threshold' => {
    'bmsLinkage' => 10
  }
}

# RabbitMQ Configuration
default['aldebaran-pms']['aldebaran-app']['config']['rabbitmq'] = {
  'queueName' => 'pms_recovery_queue',
  'port' => 5672,
  'workers' => {
    'count' => 3,
    'max' => 3
  },
  'cluster_name' => 'aldebaran'
}
