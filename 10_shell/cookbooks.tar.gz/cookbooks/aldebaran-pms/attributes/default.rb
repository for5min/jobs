#
# Cookbook Name:: aldebaran-pms
# Attributes:: default
#
# Copyright (C) 2017 Rakuten, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

# Application name
default['aldebaran-pms']['aldebaran-app']['name'] = 'pms'

# PMS specific configuration
default['aldebaran-pms']['aldebaran-app']['user'] = {
  'name' => 'pms',
  'group' => 'aldebaran'
}

# Java heap settings
default['aldebaran-pms']['aldebaran-app']['java']['heap_min'] = 1024
default['aldebaran-pms']['aldebaran-app']['java']['heap_max'] = 2048

# Rabbitmq configurations
default['aldebaran-pms']['rabbitmq'] = {
  'cluster_name' => 'aldebaran',
  'databag_name' => 'rabbitmq',
  'databag_item' => 'credentials'
}

# RabbitMQ Definition, Server recipe searches for this to create queue.
default['r-rabbitmq']['client']['queues'] = [
  { 'name' => 'expiry_queue' }
]
