# 1.0.0

* Change to cassandra config structure

# 0.6.0

* Removed custom logback.groovy, now defaults to universal script in `aldebaran-app` cookbook

# 0.1.0

* Initial release of aldebaran-pms
