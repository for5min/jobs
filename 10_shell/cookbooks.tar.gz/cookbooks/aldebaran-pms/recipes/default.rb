#
# Cookbook Name:: aldebaran-pms
# Recipe:: default
#
# Copyright (C) 2017 Rakuten, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an 'AS IS' BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

# Set aldebaran-app attributes
app_key = 'aldebaran-pms'
if node[app_key].key?('aldebaran-app')
  node[app_key]['aldebaran-app'].each_pair do |k, v|
    node.set['aldebaran-app'][k] = v
  end
end

# RabbitMQ
tag('rabbitmq-client')
rabbitmq = Chef::EncryptedDataBagItem.load(
  node[app_key]['rabbitmq']['databag_name'],
  node[app_key]['rabbitmq']['databag_item']
)
node.default['aldebaran-app']['config']['rabbitmq']['username'] = rabbitmq['username']
node.default['aldebaran-app']['config']['rabbitmq']['password'] = rabbitmq['password']
cluster_name = node[app_key]['aldebaran-app']['config']['rabbitmq']['cluster_name']
node.default['aldebaran-app']['config']['rabbitmq']['host'] = "rmq-#{cluster_name}.service.consul"
node.default['r-rabbitmq']['client']['queues'] = [
  { 'name' => node[app_key]['aldebaran-app']['config']['rabbitmq']['queueName'] }
]

# Logrotate
node.set['logrotate']['cron']['install'] = false
cron node['logrotate']['cron']['name'] do
  minute "#{Random.rand(59)}-59/20"
  command node['logrotate']['cron']['command']
  not_if 'crontab -l | grep logrotate'
end

node.default['aldebaran-app']['cookbook_version'] = run_context.cookbook_collection[cookbook_name].metadata.version

include_recipe 'aldebaran-app::default'
