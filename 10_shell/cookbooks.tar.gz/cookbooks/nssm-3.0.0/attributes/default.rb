default['nssm']['src'] = 'http://nssm.cc/release/nssm-2.24.zip'
default['nssm']['sha256'] = '727d1e42275c605e0f04aba98095c38a8e1e46def453cdffce42869428aa6743'

default['nssm']['install_location'] = '%WINDIR%'
