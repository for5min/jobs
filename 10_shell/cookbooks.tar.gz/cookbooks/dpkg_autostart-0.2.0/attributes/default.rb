default[:dpkg_autostart][:disable_actions] = %w(start restart)
default[:dpkg_autostart][:disabled_services] = []
