# Cookbook Name:: aldebaran-app
# Recipe::_filebeat
#
# Copyright (C) 2016 Rakuten, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

include_recipe 'r-filebeat'

app_name = node['aldebaran-app']['name']

# ml_java_stacktrace = {
#   # The following catches Java stack traces
#   # Aldebaran App logs should begin with a date, no backets:
#   #    2016-09-10 00:00:00.000
#   'pattern' => '^[0-9]{4}(\-[0-9]{2})?{2} ',
#   'negate' => true,
#   'match' => 'after'
# }

# Supervisor
filebeat_prospector "supervisor-#{app_name}" do
  paths ["/var/log/supervisor/#{app_name}*.log"]
  document_type 'supervisor'
  ignore_older '24h'
  scan_frequency '5s'
  harvester_buffer_size 16384
  tags ['gpp_app', app_name]

  # multiline ml_java_stacktrace
end

# Nginx
filebeat_prospector 'nginx-access' do
  paths ['/var/log/nginx/*access.log']
  document_type 'nginx-access'
  ignore_older '24h'
  scan_frequency '5s'
  harvester_buffer_size 16384
end

filebeat_prospector 'nginx-error' do
  paths ['/var/log/nginx/*error.log']
  document_type 'nginx-error'
  ignore_older '24h'
  scan_frequency '5s'
  harvester_buffer_size 16384
end

filebeat_prospector 'nginx' do
  paths ['/var/log/nginx/*.log']
  exclude_files [
    'access.log$',
    'error.log$'
  ]
  document_type 'nginx-other'
  ignore_older '24h'
  scan_frequency '5s'
  harvester_buffer_size 16384
end
