#
# Cookbook Name:: aldebaran-app
# Recipe:: _logrotate_supervisor
#
# Copyright (C) 2016 Rakuten, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

logdir = '/var/log/supervisor'
directory ::File.join(logdir, 'old') do
  recursive true
  mode '755'
end

logrotate_options = [
  'nocompress',
  'copytruncate',
  'missingok',
  'notifempty',
  'olddir old'
]

if node.key?('mounts') && node['mounts'].key?('log')
  logrotate_options << 'postrotate'
  logrotate_options << "  mkdir -p #{node['mounts']['log']}/`date +%Y`/`date +%m`"
  logrotate_options << "  ls /var/log/supervisor/old/ | xargs -I {} mv /var/log/supervisor/old/{} #{node['mounts']['log']}/`date +%Y`/`date +%m`/`date +%Y%m%d-%H%M`-{}`"
  logrotate_options << 'endscript'
end

logrotate_app 'supervisor' do
  path ::File.join(logdir, '*.log')
  frequency 'hourly'
  rotate 48
  size '100M'
  options logrotate_options
end
