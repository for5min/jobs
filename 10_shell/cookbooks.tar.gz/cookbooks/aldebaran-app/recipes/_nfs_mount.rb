#
# Cookbook Name:: aldebaran-app
# Recipe:: _newrelic
#
# Copyright (C) 2016 Rakuten, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

# Databags structure
#
# Databag: bms
#   Databag Item: mounts
#
# Example Databag:
#
# {
#   'id': 'mounts',
#   'volumes' [
#     {
#       'path': '/mnt/nbackup301',
#       'type': 'log',
#       'device': 'nbackup301-v.bk.jp.local:/gppbms_app_log',
#       'fstype': 'nfs',
#       'options': 'rw,proto=tcp,hard,intr,nfsvers=3'
#     }
#   ]
# }
#

include_recipe 'r-nfs'
include_recipe 'r-nrpe' if rakops_feature?('monitoring_nagios')

begin
  mounts_bag = node['aldebaran-app']['name']
  mounts_item = 'mounts'
  mounts_data = data_bag_item(mounts_bag, mounts_item)
  mounts_list = []
  mounts_data['volumes'].each do |volume|
    directory volume['path'] do
      mode '777'
      recursive true
    end

    mount volume['path'] do
      device volume['device']
      fstype volume['fstype']
      options volume['options']
      action [:mount, :enable]
    end

    directory ::File.join(volume['path'], node['fqdn']) do
      mode '777'
      recursive true
    end

    node.default['mounts'][volume['type']] = ::File.join(volume['path'], node['fqdn'])
    mounts_list << volume['path']
  end

  r_nrpe_check 'check_nfs_mountpoints' do
    description 'NFS Mountpoints Check'
    command "#{node['nrpe']['plugin_dir']}/check_mountpoints"
    parameters mounts_list.join(' ')
    install_source 'default/check_mountpoints.sh'
    install_method 'file'
    action :add
    not_if { mounts_list.empty? }
  end
rescue
  Chef::Log.debug('Failed to mount drives')
end
