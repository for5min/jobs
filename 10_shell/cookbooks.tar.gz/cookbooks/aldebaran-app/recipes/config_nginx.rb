#
# Cookbook Name:: aldebaran-app
# Recipe:: config_nginx
#
# Copyright (C) 2016 Rakuten, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

nginx_site 'default' do
  enable false
end

cookbook_file '/etc/nginx/conf.d/log_combined_rtt.conf' do
  source 'nginx/combined_rtt.conf'
  owner 'root'
  group 'root'
  mode '0644'
end

app_path = ::File.join('/opt', node['aldebaran-app']['name'])

backends = [{
  'name' => 'appbackend',
  'address' => format('%s:%s', '127.0.0.1', node['aldebaran-app']['config']['server']['port'])
}]

# Create site for proxy passing to backend service
nginx_site "aldebaran-app-#{node['aldebaran-app']['name']}" do
  enable true
  template 'nginx.site.conf.erb'
  variables(
    :port => node['aldebaran-app']['nginx']['port'],
    :server_root => app_path,
    :version_root => '/opt',
    :server_name => node['hostname'],
    :backends => backends,
    :proxy_location => node['aldebaran-app']['nginx']['proxy_location'],
    :static_location => []
  )
end

%w(html json).each do |f|
  aldebaran_app_version "version-#{node['aldebaran-app']['nginx']['port']}" do
    version node['aldebaran-app']['cookbook_version']
    artifact_version node['aldebaran-app']['artifact']['version']
    format f
  end
end
