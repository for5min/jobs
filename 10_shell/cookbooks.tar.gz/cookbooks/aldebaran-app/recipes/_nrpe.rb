
# Cookbook Name:: aldebaran-app
# Recipe::_nrpe
#
# Copyright (C) 2016 Rakuten, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

include_recipe 'r-nrpe'

health_endpoint = node['aldebaran-app']['health_endpoint']

ports = if app_has_slots?
          node['aldebaran-app']['slots'].map { |s| s['port'] }
        else
          [node['aldebaran-app']['nginx']['port']]
        end

ports.each do |port|
  r_nrpe_check "check_http_health_endpoint_#{port}" do
    description        "Check Health endpoint #{port}"
    command            "#{node['nrpe']['plugin_dir']}/check_http"
    parameters         "-H localhost -p #{port} -u #{health_endpoint}"
    action :add
  end
end
