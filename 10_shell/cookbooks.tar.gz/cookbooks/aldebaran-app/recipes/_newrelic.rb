#
# Cookbook Name:: aldebaran-app
# Recipe:: _newrelic
#
# Copyright (C) 2016 Rakuten, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

node.default['r-newrelic']['agent']['java']['application']['name'] = node['aldebaran-app']['name']
include_recipe 'r-newrelic::default'

# Add the app user (service user) to the newrelic group.
# This permits log writing.
app_system_user = node['aldebaran-app']['user']

group node['newrelic']['java_agent']['app_group'] do
  action :modify
  members app_system_user['user']
  append true
end
