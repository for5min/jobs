#
# Cookbook Name:: aldebaran-app
# Recipe:: slots
#
# Copyright (C) 2016 Rakuten, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

include_recipe 'aldebaran-app::install'

nginx_site 'default' do
  enable false
end

cookbook_file '/etc/nginx/conf.d/log_combined_rtt.conf' do
  source 'nginx/combined_rtt.conf'
  owner 'root'
  group 'root'
  mode '0644'
end

app_system_user = node['aldebaran-app']['user']
app_name        = node['aldebaran-app']['name']
app_path        = ::File.join('/opt', app_name)

#
# User
#
app_user = aldebaran_app_user app_system_user['name'] do
  gid app_system_user['group']
  home app_path
end

#
# Java Certificate Management
#
node['aldebaran-app']['java_certs'].each do |c|
  cert_name = c['host']
  cert_port = 443 if !c.key?('port') || !c['port']
  cert_endpoint = "#{c['host']}:#{cert_port}"
  java_libs_certificate "Install SSL Cert for #{cert_name}" do
    cert_alias cert_name
    ssl_endpoint cert_endpoint
    server_name c['host']
    action :install
  end
end

include_recipe 'aldebaran-app::_newrelic' if node['aldebaran-app']['newrelic']

slot_data = data_bag_item('slots', app_name)
slots = slot_data['slots']

slots.each do |slot|
  app_directory = "#{app_path}/#{app_name}-#{slot['port']}"
  slot_path = "#{app_directory}/#{slot['version']}"
  app_properties = ::File.join(slot_path, 'config', 'app.yaml')
  # TODO : Fix log directory
  log_directory = "#{node['aldebaran-app']['log_dir']}/#{app_name}-#{slot['port']}"

  # Backend gets prepended with '80xx', like: '8082'
  backend_port = "80#{slot['port']}"
  frontend_port = slot['port']

  # Create versioned directories in /opt to house the binary and configs
  directory slot_path do
    owner app_user.name
    mode '0755'
    action :create
    recursive true
  end

  java_opts = Array(node['aldebaran-app']['java']['options'].to_a)

  #
  # JMX Options
  #
  puts "JMX Enabled: #{node['aldebaran-app']['java']['jmx_enabled']}"
  if node['aldebaran-app']['java']['jmx_enabled']
    java_opts << '-Dcom.sun.management.jmxremote'
    node['aldebaran-app']['java']['jmx_options'].each do |k, v|
      java_opts << format('-Dcom.sun.management.jmxremote.%s=%s', k, v)
    end
  end
  puts "JMX Enabled: #{node['aldebaran-app']['java']['jmx_enabled']}"

  #
  # Java Options jiggering
  #
  # Change to explictly modify heap min/max according to number of slots and resources on VM
  total_memory = node['memory']['total'].split('kB')[0].to_i / 1024
  heap_min     = node['aldebaran-app']['java']['heap_min']
  heap_max     = node['aldebaran-app']['java']['heap_max']

  # 80% of system memory
  heap_max = [total_memory.to_f / 10.0 * 8.0, heap_min].max.to_i if heap_max.nil?

  # Slots allocate absolute heap size, divide by number of slots
  heap_max /= slots.length

  java_opts << format('-Xms%s', "#{heap_min}m")
  java_opts << format('-Xmx%s', "#{heap_max}m")
  java_opts << format('-Xloggc:%s', ::File.join(log_directory, 'gc.log'))
  java_opts << format('-XX:ErrorFile=%s', ::File.join(log_directory, 'java-%%p.log'))
  java_opts << format('-XX:HeapDumpPath=%s', ::File.join(log_directory, 'java-%%p.hprof'))
  java_opts << format('-DLOG_FILE=%s', ::File.join(log_directory, 'java.log'))

  cmd_suffix = ''
  if node['aldebaran-app']['java']['logback']
    logback_config_path = ::File.join(slot_path, 'config', node['aldebaran-app']['java']['logback'])
    cmd_suffix = "--logging.config=#{logback_config_path}"
  end

  #
  # Service
  #
  srv = aldebaran_app_service "#{app_name}-#{slot['port']}" do
    uid app_user.name
    jar_file ::File.join(app_directory, 'current', "#{app_name}.jar")
    command_prefix node['aldebaran-app']['service']['command_prefix']
    command_suffix cmd_suffix
    config_file app_properties
    service_dir slot_path
    java_options java_opts
    service_action [:enable]
  end

  # Add the agent jar only if it is included.
  srv.agent_jar = '/opt/newrelic/newrelic.jar' if node['aldebaran-app']['newrelic']
  # srv.agent_options = ...

  backends = [{
    'name' => 'appbackend',
    'address' => format('%s:%s', '127.0.0.1', backend_port)
  }]

  # Create site for proxy passing to backend service
  nginx_site "#{node['aldebaran-app']['name']}-#{frontend_port}" do
    enable true
    template 'nginx.site.conf.erb'
    variables(
      :port => frontend_port,
      :server_root => slot_path,
      :version_root => '/opt',
      :server_name => node['hostname'],
      :backends => backends,
      :proxy_location => node['aldebaran-app']['nginx']['proxy_location'],
      :static_location => []
    )
  end

  %w(html json).each do |f|
    aldebaran_app_version "version-#{frontend_port}" do
      version node['aldebaran-app']['cookbook_version']
      artifact_version slot['version']
      slot_name slot['name']
      format f
    end
  end

  # Only deploy code and restart services if slots are in the right state
  # case slot['status']
  if slot['status'] == 'enabled' || node['aldebaran-app']['bootstrap_slot']
    # Deploy jar using the slot version attribute
    art = node['aldebaran-app']['artifact']
    artifact_file "#{app_name}-#{slot['port']}" do
      location format('%s:%s:%s:%s', art['group_id'], art['id'], art['format'], slot['version'])
      path "#{slot_path}/#{app_name}.jar"
      owner app_user.name
      group app_user.gid

      conf = node['aldebaran-app']['config'].to_hash
      conf['server']['port'] = backend_port
      nexus_configuration Chef::Artifact::NexusConfiguration.new(art['nexus']['url'], art['nexus']['repository'])
      after_download proc {
        # Config
        aldebaran_app_config ::File.join(slot_path, 'config', node['aldebaran-app']['config_file']) do
          install_dir slot_path
          log_dir log_directory

          service_name "#{app_name}-#{slot['port']}"

          uid app_user.name
          gid app_user.gid

          cluster_name node['aldebaran-app']['cassandra']['cluster']
          data_center node['aldebaran-app']['cassandra']['datacenter']

          config_variables conf
        end

        cookbook_file ::File.join(slot_path, 'config', 'logback.groovy') do
          source node['aldebaran-app']['java']['logback']
          cookbook node['aldebaran-app']['java']['logback_cookbook']
          owner app_user.name
          group app_user.gid
          mode '0755'
          action :create
          only_if { node['aldebaran-app']['java']['logback'] }
        end

        # # stop current slot service
        # supervisor_service "#{app_name}-#{slot['port']}" do
        #   action :stop
        #   ignore_failure true
        # end

        log "#{app_name}-#{slot['port']}-complete" do
          message "Successfully deployed #{slot['name']} version: #{slot['version']} to #{slot['name']}-#{slot['port']}"
          level :info
        end
      }
    end

    # symlink the latest version with the current
    link ::File.join(app_directory, 'current') do
      to slot_path
      notifies :restart, "aldebaran_app_service[#{app_name}-#{slot['port']}]", :immediately
    end

    # (re)start current slot service
    # supervisor_service "#{app_name}-#{slot['port']}" do
    #   action :restart
    # end

  elsif slot['status'] == 'default'
    # Store a reference / symlink to the current default slot
    link ::File.join(app_path, 'default') do
      to ::File.join(app_directory, 'current')
    end

    # start current slot service
    supervisor_service "#{app_name}-#{slot['port']}" do
      action :start
    end
  elsif slot['status'] == 'disabled'
    # stop current slot service
    supervisor_service "#{app_name}-#{slot['port']}" do
      action :stop
    end
  else
    log "#{app_name}-#{slot['port']}-nothing" do
      message "No deployment actions performed on #{app_name}-#{slot['port']}, status: #{slot['status']}"
      level :info
    end
  end
end

node.set['aldebaran-app']['bootstrap_slot'] = false

ruby_block 'Save Node Data' do
  block { node.save }
end
