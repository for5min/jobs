#
# Cookbook Name:: aldebaran-app
# Recipe:: config_java
#
# Copyright (C) 2016 Rakuten, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

app_user       = node['aldebaran-app']['user']
app_name       = node['aldebaran-app']['name']
app_path       = ::File.join('/opt', app_name)
log_directory  = ::File.join('/var/log', app_name)

#
# User
#
app_user = aldebaran_app_user app_user['name'] do
  gid app_user['group']
  home app_path
end

#
# Config
#
conf = node['aldebaran-app']['config']
app_config = aldebaran_app_config ::File.join(app_path, 'config', node['aldebaran-app']['config_file']) do
  install_dir app_path
  log_dir log_directory

  service_name app_name

  uid app_user.name
  gid app_user.gid

  cluster_name node['aldebaran-app']['cassandra']['cluster']
  data_center node['aldebaran-app']['cassandra']['datacenter']

  config_variables conf.to_hash
end

service_action = [:enable, :start]
art = node['aldebaran-app']['artifact']
unless art.nil?
  jar_name = format('%s-%s.%s', art['id'], art['version'], art['format'])
  nexus_config = Chef::Artifact::NexusConfiguration.new(art['nexus']['url'], art['nexus']['repository'])
  symlink_path = ::File.join(app_path, 'builds', 'latest.jar')
  current_link_target = ::File.realpath(symlink_path) if ::File.exist?(symlink_path)
  jar_full_path = ::File.join(app_path, 'builds', jar_name)

  artifact_file jar_full_path do
    location format('%s:%s:%s:%s', art['group_id'], art['id'], art['format'], art['version'])
    nexus_configuration nexus_config
    owner app_user.name
    group app_user.gid
    retries 3
  end

  link symlink_path do
    to jar_full_path
    owner app_user.name
    group app_user.gid
  end

  service_action = [:enable, :restart] if current_link_target != jar_full_path
end

#
# Java Certificate Management
#
node['aldebaran-app']['java_certs'].each do |c|
  cert_name = c['host']
  cert_port = 443 if !c.key?('port') || !c['port']
  cert_endpoint = "#{c['host']}:#{cert_port}"
  java_libs_certificate "Install SSL Cert for #{cert_name}" do
    cert_alias cert_name
    ssl_endpoint cert_endpoint
    server_name c['host']
    action :install
  end
end

java_opts = Array(node['aldebaran-app']['java']['options'].to_a)

#
# JMX Options
#
if node['aldebaran-app']['java']['jmx_enabled']
  java_opts << '-Dcom.sun.management.jmxremote'
  node['aldebaran-app']['java']['jmx_options'].each do |k, v|
    java_opts << format('-Dcom.sun.management.jmxremote.%s=%s', k, v)
  end
end

#
# Java Options jiggering
#
total_memory = node['memory']['total'].split('kB')[0].to_i / 1024
heap_min     = node['aldebaran-app']['java']['heap_min']
heap_max     = node['aldebaran-app']['java']['heap_max']
heap_max     = [total_memory / 4 * 3, heap_min].max if heap_max.nil?

java_opts << format('-Xms%s', "#{heap_min}m")
java_opts << format('-Xmx%s', "#{heap_max}m")
java_opts << format('-Xloggc:%s', ::File.join(log_directory, 'gc.log'))
java_opts << format('-XX:ErrorFile=%s', ::File.join(log_directory, 'java-%%p.log'))
java_opts << format('-XX:HeapDumpPath=%s', ::File.join(log_directory, 'java-%%p.hprof'))
java_opts << format('-DLOG_FILE=%s', ::File.join(log_directory, 'java.log'))

service_env_vars = {}
service_env_vars = node['aldebaran-app']['service']['environment'] unless node['aldebaran-app']['service']['environment'].empty?

# Command Suffix
cmd_suffix = ''
if node['aldebaran-app']['java']['logback']
  logback_config_path = ::File.join(app_path, 'config', node['aldebaran-app']['java']['logback'])
  cmd_suffix = "--logging.config=#{logback_config_path}"
end

cookbook_file ::File.join(app_path, 'config', 'logback.groovy') do
  source node['aldebaran-app']['java']['logback']
  cookbook node['aldebaran-app']['java']['logback_cookbook']
  owner app_user.name
  group app_user.gid
  mode '0755'
  action :create
  only_if { node['aldebaran-app']['java']['logback'] }
end

#
# Service
#
aldebaran_app_service app_name do
  uid app_user.name
  # gid app_user.gid

  jar_file ::File.join(app_path, 'builds', 'latest.jar')
  command_prefix node['aldebaran-app']['service']['command_prefix']
  command_suffix cmd_suffix
  config_file app_config.name
  service_dir app_path
  environment service_env_vars

  java_options java_opts
  service_action service_action

  only_if { node['aldebaran-app']['service']['enabled'] }
end
