#
# Cookbook Name:: aldebaran-resources
# Library:: helpers
#
# Copyright (C) 2016 Rakuten, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

module AldebaranApp
  module Helpers
    def nil_or_empty?(value)
      value.nil? || value.respond_to?(:empty?) && value.empty?
    end

    def app_slots
      # rubocop:disable Style/RedundantBegin
      begin
        data_bag_item('slots', node['aldebaran-app']['name'])
      rescue
        []
      end
      # rubocop:enable Style/RedundantBegin
    end

    def app_has_slots?
      !app_slots.empty?
    end

    # rubocop:disable AbcSize
    def merge_app_attributes(app_key)
      return unless node[app_key].key?('aldebaran-app')

      node[app_key]['aldebaran-app'].each_pair do |k, v|
        node.default['aldebaran-app'][k] = v if k != 'config'
      end
      node[app_key]['aldebaran-app']['config'].each_pair do |k, v|
        node.default['aldebaran-app']['config'][k] = v
      end
    end
    # rubocop:enable AbcSize
  end
end

[::Chef::Recipe, ::Chef::Resource].each do |o|
  o.send :include, ::AldebaranApp::Helpers
end
