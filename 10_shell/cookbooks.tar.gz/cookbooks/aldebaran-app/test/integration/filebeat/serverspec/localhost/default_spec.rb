require 'spec_helper'

describe service('filebeat') do
  it { should be_enabled }
  it { should be_running }
end

describe file('/etc/filebeat/conf.d/prospector-nginx-access.yml') do
  it { should exist }
  it { should be_file }
end

describe '/etc/filebeat/conf.d/prospector-nginx-access.yml' do
  config_file = YAML.load_file('/etc/filebeat/conf.d/prospector-nginx-access.yml')
  it 'has been configured correctly' do
    expect(config_file['filebeat']).to have_key('prospectors')
    expect(config_file['filebeat']['prospectors']).to be_an(Array)
    expect(config_file['filebeat']['prospectors'][0]['paths'][0]).to eq('/var/log/nginx/*access.log')
    expect(config_file['filebeat']['prospectors'][0]['paths'][0]).to eq('/var/log/nginx/*access.log')
    expect(config_file['filebeat']['prospectors'][0]['document_type']).to eq('nginx-access')
    expect(config_file['filebeat']['prospectors'][0]['ignore_older']).to eq('24h')
  end
end
