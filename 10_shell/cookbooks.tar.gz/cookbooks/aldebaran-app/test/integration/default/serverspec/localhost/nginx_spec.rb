require 'spec_helper'

describe 'Nginx' do
  describe file('/etc/nginx/sites-available/aldebaran-app-testy') do
    it { should exist }
    it { should be_file }
    its(:content) { should contain 'set \$appbackend 127.0.0.1:8080' }
    its(:content) { should contain 'proxy_pass http://\$appbackend;' }
  end

  describe file('/etc/nginx/sites-enabled/aldebaran-app-testy') do
    it { should exist }
    it { should be_symlink }
  end

  describe file('/etc/nginx/sites-available/nginx_status') do
    it { should exist }
    it { should be_file }
    its(:content) { should contain 'listen 8090;' }
  end

  describe file('/etc/nginx/sites-enabled/nginx_status') do
    it { should exist }
    it { should be_symlink }
  end
end
