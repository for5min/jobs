require 'spec_helper'

describe 'Java application' do
  describe file('/opt/testy/builds') do
    it { should exist }
    it { should be_directory }
  end

  describe file('/opt/testy/builds/testy-0.0.1-1.jar') do
    it { should exist }
    it { should be_file }
  end

  describe file('/opt/testy/builds/latest.jar') do
    it { should exist }
    it { should be_symlink }
  end

  describe file('/opt/testy/config') do
    it { should exist }
    it { should be_directory }
  end

  describe file('/opt/testy/config/app.yaml') do
    it { should exist }
    it { should be_file }
    its(:content) { should contain 'port: 8080' }
  end

  describe file('/var/log/supervisor/testy-stdout.log') do
    it { should exist }
    it { should be_file }
  end
end
