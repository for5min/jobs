require 'spec_helper'

describe 'Version information' do
  describe file('/opt/version.html') do
    it { should exist }
    it { should be_file }
    it { should be_owned_by 'root' }
    it { should be_grouped_into 'root' }
    its(:content) { should match %r{<h1>TESTY<\/h1>} }
  end

  describe file('/opt/version.json') do
    it { should exist }
    it { should be_file }
    it { should be_owned_by 'root' }
    it { should be_grouped_into 'root' }
    its(:content) { should match(/"name": "TESTY"/) }
  end
end
