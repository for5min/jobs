name 'aldebaran-app-test'
version '0.1.0'

depends 'aldebaran-app'
depends 'java-service-test-helper'
