default['aldebaran-app']['cassandra']['cluster']    = 'test_cluster'
default['aldebaran-app']['cassandra']['datacenter'] = 'test_datacenter'
