# Fix fully-qualified domain name resolution.
file '/etc/hosts' do
  content <<-EOF
127.0.0.1 localhost
127.0.1.1 #{node['hostname']}.localdomain #{node['hostname']}
127.0.1.2 cassandra-server.example.com cassandra-server
127.0.1.3 rabbitmq-server.example.com rabbitmq-server
  EOF
end

# To make sure that Ohai knows about changes.
ohai 'reload' do
  plugin 'hostname'
end

# node.default['idc-platform-rest']['service']['action'] = %i(enable start)

# node.default['idc-platform-rest']['cassandra'].update({
#   'servers' => 'cassandra-server.example.com'
# })

# node.default['idc-platform-rest']['rabbitmq'].update({
#   'server' => 'rabbitmq-server.example.com',
#   'port' => 5672
# })

# node.default['idc-test-helper']['service'] = 'idc-platform-rest'

node.default['aldebaran-app']['name'] = 'testy'
node.default['aldebaran-app']['user'] = {
  'name' => 'testy',
  'group' => 'testy'
}

node.default['aldebaran-app']['cookbook_version'] = run_context.cookbook_collection[cookbook_name].metadata.version

app_name = node['aldebaran-app']['name']
jar_name = "#{app_name}-0.0.1-1.jar"
jar_path = ::File.join('/opt', app_name, 'builds')

directory jar_path do
  owner 'root'
  group 'root'
  recursive true
  action :create
end

fake_service_jar ::File.join(jar_path, jar_name) do
  link_name ::File.join(jar_path, 'latest.jar')
end

aldebaran_app_version 'testy' do
  version node['aldebaran-app']['cookbook_version']
  username 'root'
  groupname 'root'
end

node.set['rakops']['features']['monitoring_nagios'] = true
include_recipe 'aldebaran-app::default'
