#
# Cookbook Name:: aldebaran-app
# Attributes:: java
#
# Copyright (C) 2016 Rakuten, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

default['r-java']['install_flavor'] = 'openjdk'

default['aldebaran-app']['java']['heap_min'] = 256
default['aldebaran-app']['java']['heap_max'] = nil

default['aldebaran-app']['java']['options'] = [
  '-server',
  '-verbose:gc',
  '-XX:+PrintGCDetails',
  '-XX:+PrintGCTimeStamps',
  '-XX:+PrintGCDateStamps',
  '-XX:+PrintTenuringDistribution',
  '-XX:+PrintGCApplicationConcurrentTime',
  '-XX:+PrintGCApplicationStoppedTime',
  '-XX:+UseGCLogFileRotation',
  '-XX:NumberOfGCLogFiles=10',
  '-XX:GCLogFileSize=50M',
  '-XX:+DisableExplicitGC',
  '-XX:+ScavengeBeforeFullGC',
  '-XX:+UseG1GC',
  '-XX:MaxGCPauseMillis=256',
  '-XX:InitiatingHeapOccupancyPercent=75',
  '-XX:+UseTLAB',
  '-XX:+ResizeTLAB',
  '-XX:+AggressiveOpts',
  '-XX:+AlwaysPreTouch',
  '-XX:+UseBiasedLocking',
  '-XX:+OptimizeStringConcat',
  '-XX:+UseCompressedOops',
  '-XX:+UseFastAccessorMethods',
  '-XX:+HeapDumpOnOutOfMemoryError',
  '-Dsun.net.inetaddr.ttl=60',
  '-Djava.net.preferIPv4Stack=true',
  '-Djava.awt.headless=true'
]

default['aldebaran-app']['java']['jmx_enabled'] = false
default['aldebaran-app']['java']['jmx_options'] = {
  'port' => '9010',
  'rmi.port' => '9011',
  'local.only' => 'false',
  'authenticate' => 'false',
  'ssl' => 'false'
}

default['aldebaran-app']['java']['logback'] = 'logback.groovy'
default['aldebaran-app']['java']['logback_cookbook'] = 'aldebaran-app'

default['aldebaran-app']['java_certs'] = []

default['aldebaran-app']['service']['enabled'] = true
default['aldebaran-app']['service']['command_prefix'] = ''
default['aldebaran-app']['service']['environment'] = {}

default['aldebaran-app']['newrelic'] = false
default['r-newrelic']['agent']['java']['install'] = true
