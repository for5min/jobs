#
# Cookbook Name:: aldebaran-app
# Attributes:: components
#
# Copyright (C) 2016 Rakuten, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

# This is a list of Aldebaran components URIs etc, for service discovery.
# This list is used for a single environment (STG at time of writing), and
# should be overwritten in the Chef ENVIRONMENT of any other environments
# such as PRO or DEV.
default['aldebaran-app']['host-urls'] = {
  'pcms'        => 'https://stg-gpoint-pcms.stg.jp.local',
  'pms'         => 'https://stg-gpoint-api.stg.jp.local',
  'pmsadmin'    => 'https://stg-gpoint-admin.stg.jp.local',
  'reservation' => 'https://stg-gpoint-res.stg.jp.local',
  'scheduler'   => 'https://stg-gpoint-sched.stg.jp.local',
  'pointclub'   => 'https://stg-gpoint-club-jp.stg.jp.local'
}
