import ch.qos.logback.classic.encoder.PatternLayoutEncoder
import ch.qos.logback.core.ConsoleAppender
import com.rakuten.point.common.logging.ContextField

appender("STDOUT", ConsoleAppender) {
    encoder(PatternLayoutEncoder) {
        pattern = "%d{yyyy-MM-dd'T'HH:mm:ss.SSS}\\t[%p]\\t[%c]\\t|%m|\\t%t\\t%F\\t%L\\t%X{${ContextField.MESSAGE_ID}}%n"
    }
}

appender("PMS_CONSOLE", ConsoleAppender) {
    encoder(PatternLayoutEncoder) {
        pattern = "%d{yyyy-MM-dd'T'HH:mm:ss.SSS}\\t[%p]\\t[%c]\\t|%X{${ContextField.API_NAME}}|%m|\\t%t\\t%F\\t%L\\t%X{${ContextField.MESSAGE_ID}}%n"
    }
}

appender("PMS_ADVICE", ConsoleAppender) {
    encoder(PatternLayoutEncoder) {
        pattern = "%d{yyyy-MM-dd'T'HH:mm:ss.SSS}\\t[%p]\\t[%c]\\t|%X{${ContextField.API_NAME}}|%m|%X{${ContextField.HTTP_REQUEST_URL}}|\\t%t\\t%F\\t%L\\t%X{${ContextField.MESSAGE_ID}}%n"
    }
}

// Don't need output log
logger("org.springframework", ERROR, ["STDOUT"], false)
logger("ch.qos.logback", ERROR, ["STDOUT"], false)
logger("com.rakuten.point.logger.CQL", ERROR, ["STDOUT"], false)
logger("com.rakuten.point.logger.Performance", DEBUG, ["STDOUT"], false)

logger("pmsApi", INFO, ["PMS_CONSOLE"], false)
logger("pmsHttp", INFO, ["PMS_CONSOLE"], false)
logger("pmsPerf", INFO, ["PMS_CONSOLE"], false)
logger("pmsService", INFO, ["PMS_CONSOLE"], false)
logger("pmsAsync", INFO, ["PMS_CONSOLE"], false)
logger("pmsRecoveryHandler", INFO, ["PMS_CONSOLE"], false)
logger("pmsAuth", INFO, ["PMS_CONSOLE"], false)
logger("pmsDao", INFO, ["PMS_CONSOLE"], false)
logger("pmsStats", INFO, ["PMS_CONSOLE"], false)
logger("pmsAdvice", INFO, ["PMS_ADVICE"], false)

// PMS Admin
logger("pmsAdmin", INFO, ["PMS_CONSOLE"], false)
logger("pmsAdminHttp", INFO, ["PMS_CONSOLE"], false)

//Point Club
logger("pointClubInternalService", INFO, ["PMS_CONSOLE"], false)
logger("pointClubPerf", INFO, ["PMS_CONSOLE"], false)
logger("pointClubHttp", INFO, ["PMS_CONSOLE"], false)

//CS Tool
logger("csToolConfig", INFO, ["PMS_CONSOLE"], false)
logger("csToolHttp", INFO, ["PMS_CONSOLE"], false)
logger("csToolService", INFO, ["PMS_CONSOLE"], false)
logger("csToolAuth", INFO, ["PMS_CONSOLE"], false)
logger("csToolPerf", INFO, ["PMS_CONSOLE"], false)

//Scheduler
logger("schedulerApi", INFO, ["PMS_CONSOLE"], false)
logger("schedulerService", INFO, ["PMS_CONSOLE"], false)
logger("schedulerCommon", INFO, ["PMS_CONSOLE"], false)

root(INFO, ["STDOUT"])

