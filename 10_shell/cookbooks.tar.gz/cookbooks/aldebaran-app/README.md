# aldebaran-app-cookbook

This cookbook forms the base for all apps (springboot based) for the Aldebaran project.

## Supported Platforms

* Ubuntu 14.04 (Target deployment OS)
* Ubuntu 16.04

## Attributes

| Key | Type | Description | Default |
| --- | ---- | ----------- | ------- |
| `['aldebaran-app']['java_certs']` | Array | List of SSL certs to import to the java keystore (See below for detailed description) | `nil` |

### `java_certs` attribute

This is an array of hosts to pull certs from, for installation into the Java `cacerts` KeyStore. This is handy if you have selfsigned certs, so that java applications can correctly connect to SSL endpoints.

Only the `host` part for each entry is required. If no port is specified, it assumes `443`.

Examples:

```
default['aldebaran-app']['java_certs'] = [
  {
    'host' => 'rakuten.com'
  },
  {
    'host' => 'foo.com',
    'port' => 1234
  }
]
```

## Usage

### aldebaran-app::default

Include `aldebaran-app` in your node's `run_list`:

```json
{
  "run_list": [
    "recipe[aldebaran-app::default]"
  ]
}
```

## License and Authors

Author:: Rakuten, Inc. (<ops@rakops.com>)
