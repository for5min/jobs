#
# Cookbook Name:: aldebaran-app
# Resource:: aldebaran_app_config
#
# Copyright (C) 2016 Rakuten, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

property :config_file, name_property: true
property :config_variables, Hash, default: {}
property :install_dir, String
property :service_name, String
property :log_dir, String
property :uid, String
property :gid, String
property :keyspace, String
property :cluster_name, String, default: 'cluster1'
property :data_center, String, default: 'dc1'
property :search_environment, String, default: node.chef_environment
property :directories, Array, default: %w(builds config log logs)

default_action :create

#
# Create
#
action :create do
  directory install_dir do
    owner uid
    group gid
    mode '0750'
    recursive true
  end
  directories.each do |d|
    directory ::File.join(install_dir, d) do
      owner uid
      group gid
      mode '0750'
    end
  end

  directory log_dir do
    owner uid
    group gid
    mode '0700'
    recursive true
  end

  # searches and adds cassandra servers
  if nil_or_empty? config_variables['cassandra']['hosts']
    # Fail when using chef search with chef solo
    if Chef::Config[:solo]
      raise 'This recipe uses search. Chef Solo does not support search.'
    end
    query =
      "chef_environment:#{search_environment} AND tags:cassandra AND cassandra_config_cluster_name:#{cluster_name} AND cassandra_rackdc_dc:#{data_center}"
    nodes = search(:node, query, filter_result: {
      'fqdn' => ['fqdn'],
      'cassandra_port' => %w(cassandra config native_transport_port)
    })
    nodes.map! { |n| n['fqdn'] + ':' + n['cassandra_port'] }
    nodes.sort!
    config_variables['cassandra']['hosts'] = nodes.join(', ')
  end

  # Unless cassandra username is already set by the application cookbook,
  # look for the app_name data bag item in cassandra_users databag to get
  # the credentials. If neither is present, leave empty.
  if config_variables['cassandra']['username'].empty?
    dse_auth = begin
      Chef::EncryptedDataBagItem.load(
        node['aldebaran-app']['cassandra_auth']['data_bag'],
        node['aldebaran-app']['cassandra_auth']['data_bag_item'].empty? ? service_name.split('-')[0] : node['aldebaran-app']['cassandra_auth']['data_bag_item']
      )
    rescue Net::HTTPServerException, Chef::Exceptions::InvalidDataBagPath
      nil
    end

    if dse_auth
      config_variables['cassandra']['username'] = dse_auth['user']
      config_variables['cassandra']['password'] = dse_auth['password']
    end
  end

  # template config_file do
  #   helpers ::AldebaranApp::Helpers
  #   # source "#{::File.basename(config_file)}.erb"
  #   source 'app.properties.erb'
  #   owner uid
  #   group gid
  #   variables(config_variables)
  # end

  # config_variables['cassandra']['keyspace'] = node['aldebaran-app']['cassandra']['keyspace']
  file config_file do
    content config_variables.to_yaml(:line_width => -1)
    owner uid
    group gid

    notifies :restart, "aldebaran_app_service[#{service_name}]", :delayed
  end
end

#
# Delete
#
action :delete do
  directories.each do |d|
    directory ::File.join(install_dir, d) do
      action :delete
    end
  end

  directory log_dir do
    action :delete
  end

  file config_file do
    action :delete
  end
end
