#
# Cookbook Name:: aldebaran-app
# Resource:: aldebaran_app_service
#
# Copyright (C) 2016 Rakuten, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

property :name, String, name_property: true
property :java_options, Array
property :command_prefix, String, default: ''
property :command_suffix, String, default: ''
property :environment, Hash, default: {}
property :jar_file, String
property :service_dir, String
property :config_file, String
property :uid, String
property :start_seconds, Integer, default: 1
property :auto_restart, [TrueClass, FalseClass], default: true
property :agent_jar, String
property :agent_options, String
property :log_stdout, String
property :log_stderr, String
property :retries, Integer, default: 3
property :retry_delay, Integer, default: 5
property :service_action, Array, default: %w(enable start)

default_action :create

action :create do
  unless nil_or_empty? agent_jar
    options = format('-javaagent:%s', agent_jar)
    options = "#{options}=#{agent_options}" unless nil_or_empty? agent_options
    java_options.insert 0, options
  end

  java_options_str = java_options.join(' ')
  pre_command = ''
  pre_command = "#{command_prefix} " unless command_prefix.strip.empty?

  supervisor_service name do
    command "#{pre_command}java #{java_options_str} -jar #{jar_file} --spring.config.location=#{config_file} #{command_suffix}"
    user uid
    directory service_dir
    startsecs start_seconds
    autorestart auto_restart
    stdout_logfile log_stdout || ::File.join('/var/log/supervisor', "#{new_resource.name}-stdout.log")
    stderr_logfile log_stderr || ::File.join('/var/log/supervisor', "#{new_resource.name}-stderr.log")
    environment new_resource.environment

    # Disable internal log rotation, use logrotate instead.
    stdout_logfile_maxbytes '0'
    stdout_logfile_backups 0
    stderr_logfile_maxbytes '0'
    stderr_logfile_backups 0

    retries new_resource.retries
    retry_delay new_resource.retry_delay

    action service_action
  end
end

action :start do
  supervisor_service name do
    action :start
  end
end

action :delayed_start do
  supervisor_service name do
    action :start, :delayed
  end
end

action :stop do
  supervisor_service name do
    action :stop
  end
end

action :restart do
  supervisor_service name do
    action :restart
  end
end
