#
# Cookbook Name:: aldebaran-app
# Resource:: aldebaran_app_version
#
# Copyright (C) 2016 Rakuten, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

property :name, String, name_property: true
property :app_path, String, default: '/opt'
property :version, String
property :username, String, default: ''
property :groupname, String, default: ''
property :format, String, default: 'html'
property :artifact_id, String, default: 'app'
property :artifact_version, String, default: '1.0'
property :fqdn, String, default: ''
property :slot_name, String, default: ''

default_action :create

action :create do
  file_path = ::File.join(app_path, "#{name}.#{new_resource.format}")
  app = node['aldebaran-app']

  template file_path do
    source "version.#{new_resource.format}.erb"
    cookbook 'aldebaran-app'
    user   new_resource.username.empty? ? app['user']['name'] : new_resource.username
    group  new_resource.groupname.empty? ? app['user']['group'] : new_resource.groupname
    mode   '644'
    variables(
      :app_name => app['name'],
      :cookbook_version => new_resource.version,
      :artifact => {
        'id' => app['artifact'].nil? ? new_resource.artifact_id : app['artifact']['id'],
        'version' => new_resource.artifact_version
      },
      :slot => new_resource.slot_name,
      :fqdn => new_resource.fqdn.empty? ? node['fqdn'] : new_resource.fqdn
    )
  end
end
