# 2.0.0

* Update groovy logback, Koba's first release

# 1.5.1

* Updated logback.groovy config

# 1.5.0

* Added tags to the filebeat logs

# 1.4.8

* Move logs to NFS without overwrite

# 1.4.7

* Monitoring for NFS Mounts

# 1.4.6

* HOTFIX: Added NFS Mounts to fstab

# 1.4.2

* Remove log compression, support mount points

# 1.4.1

* Minor JSON Fix

# 1.4.0

* Added universal logback.groovy for all apps

# 1.3.6

* Fancy version of the .. version page.

# 1.3.2

* Default slot symlink

# 1.3.1

* HOTFIX: Move 'current' directory symlink creation outside of download proc{} block

# 1.3.0

* Dependency resource change in Java_libs

# 1.2.1

* Change from java-libraries dependency to java_libs

# 1.1.0

* Simplify configuration
* Central encoding implementation
* Central component URL defintiion

# 1.0.1

* Added health check options

# 1.0.0

* Refactor configuration
* simplify config merge

# 0.8.1

* Add cassandra-auth

# 0.1.0

* Initial release of aldebaran-app
