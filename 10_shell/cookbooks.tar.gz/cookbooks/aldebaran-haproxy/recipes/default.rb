#
# Cookbook Name:: aldebaran-haproxy
# Recipe:: default
#
# Copyright (C) 2017 Rakuten, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

tag('haproxy')
tag('aldebaran-loadbalancer')

# node.default['haproxy']['package']['version'] = '1.6.9-1ppa1~trusty'

node.default['haproxy']['balance_algorithm'] = 'roundrobin'
node.default['haproxy']['mode'] = 'http'
node.default['haproxy']['enable_admin'] = true
node.default['haproxy']['admin']['address_bind'] = '0.0.0.0'
node.default['haproxy']['syslog']['length'] = 2048

if Chef::Config[:solo]
  raise 'This cookbook relies on Chef Search, and thus must be used with Chef Server or Chef zero.'
end

include_recipe 'aldebaran-haproxy::_apt'
include_recipe "haproxy::install_#{node['haproxy']['install_method']}"
directory node['haproxy']['cert_dir']

service 'rsyslog' do
  supports 'restart' => true, 'status' => true, 'reload' => true
  action [:enable, :start]
end

# TODO: Update with haproxy user
cookbook_file '/etc/default/haproxy' do
  source 'haproxy-default'
  owner 'root'
  group 'root'
  mode '0644'
  notifies :restart, 'service[haproxy]', :delayed
  notifies :restart, 'service[rsyslog]', :immediately
end

if node['haproxy']['enable_admin']
  admin = node['haproxy']['admin']
  haproxy_lb 'admin' do
    bind "#{admin['address_bind']}:#{admin['port']}"
    mode 'http'
    params(admin['options'])
  end
end

include_recipe 'aldebaran-haproxy::_custom_errors'

#
# HealthCheck Backend
#
haproxy_lb 'healthcheck' do
  type 'backend'
  params(
    [
      'errorfile 503 /etc/haproxy/errors/200wwwcheck.http'
    ]
  )
end

directory '/etc/haproxy/ssl'

#
# Slots
#
slotted_apps = data_bag('slots')
slotted_apps.each do |app_name|
  app_slot_data = data_bag_item('slots', app_name)

  #
  # SSL Management
  #
  if app_slot_data['load_balancer']['ssl']['terminate']
    Chef::EncryptedDataBagItem.load('ssl', app_name)['certs'].each do |cert_data|
      domain = cert_data['domain']
      cert_dir = directory ::File.join(node['haproxy']['cert_dir'], domain)
      full_pem = ''

      %w(key cert chain).each do |cert_part|
        file ::File.join(cert_dir.path, "#{domain}.#{cert_part}") do
          content cert_data[cert_part]
        end
        full_pem = "#{full_pem}#{cert_data[cert_part]}\n"
      end

      file ::File.join(node['haproxy']['cert_dir'], "#{domain}.pem") do
        content full_pem
        notifies :reload, 'service[haproxy]', :delayed
      end
    end
  end

  #
  # Backend
  #
  default_backend = nil
  app_slot_data['slots'].each do |slot|
    backend_params = []
    default_backend = "#{app_name}-#{slot['port']}" if slot['status'] == 'default'

    # TODO: Replace with tags
    app_servers = search(:node, "tags:#{app_name}").sort_by { |n| n['hostname'] }
    app_servers.each do |s|
      backend_params << "server #{s['hostname']}_#{slot['port']} #{s['fqdn']}:#{slot['port']} check"
    end
    backend_params << 'default-server inter 5s fall 3 rise 2'

    haproxy_lb "#{app_name}-#{slot['port']}" do
      type 'backend'
      params(backend_params)
    end
  end

  #
  # Frontend
  #
  ssl_params = ''
  if app_slot_data['load_balancer']['ssl']['terminate']
    ssl_params = "#{ssl_params} ssl crt #{node['haproxy']['cert_dir']}/"
    ssl_params = "#{ssl_params} no-tls-tickets ciphers EECDH+aRSA+AESGCM:EECDH+aRSA+SHA384:EECDH+aRSA+SHA256:EECDH+aRSA+RC4:EECDH:EDH+aRSA:!aNULL:!eNULL:!LOW:!MEDIUM:!SEED:!3DES:!CAMELLIA:!MD5:!EXP:!PSK:!SRP:!DSS:!RC4 no-sslv3"
  end

  frontend_params = []
  frontend_params << "bind :#{app_slot_data['load_balancer']['port']}#{ssl_params}"
  frontend_params << 'acl health_page path_beg /health'
  frontend_params << 'acl version_page path_beg /version'
  frontend_params << "acl internal_domain hdr_sub(host) -i #{node['domain']}"
  frontend_params << 'http-request deny if health_page !internal_domain'
  frontend_params << 'http-request deny if version_page !internal_domain'
  frontend_params << 'reqadd X-Forwarded-Proto:\ http' unless app_slot_data['load_balancer']['ssl']['terminate']
  frontend_params << 'reqadd X-Forwarded-Proto:\ https' if app_slot_data['load_balancer']['ssl']['terminate']
  frontend_params << 'acl wwwcheck path /wwwcheck.html'
  frontend_params << 'use_backend healthcheck if wwwcheck'

  app_slot_data['slots'].each do |slot|
    frontend_params << "acl slot_bypass_#{slot['port']} req.cook(SlotOverride-#{app_name}) #{slot['cookie']}"
    frontend_params << "use_backend #{app_name}-#{slot['port']} if slot_bypass_#{slot['port']}"
  end
  default_backend ||= "#{app_name}-#{app_slot_data['slots'][0]['port']}"
  frontend_params << "default_backend #{default_backend}"

  haproxy_lb "front-#{app_name}" do
    type 'frontend'
    params(frontend_params)
  end
end

#
# Generate configuration file
#
template ::File.join(node['haproxy']['conf_dir'], 'haproxy.cfg') do
  source 'haproxy.cfg.erb'
  owner 'root'
  group 'root'
  mode '0644'
  variables(
    'defaults_options' => haproxy_defaults_options,
    'defaults_timeouts' => haproxy_defaults_timeouts
  )
  notifies :reload, 'service[haproxy]', :delayed
  # notifies :run, 'execute[reload-haproxy]', :delayed
end

service 'haproxy' do
  supports 'restart' => true, 'status' => true, 'reload' => true
  action [:enable, :start]
end
