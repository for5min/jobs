#
# Cookbook Name:: aldebaran-haproxy
# Recipe:: ha
#
# Copyright (C) 2017 Rakuten, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

include_recipe 'sysctl::default'
sysctl_param 'net.ipv4.ip_nonlocal_bind' do
  value 1
end
include_recipe 'aldebaran-haproxy::default'

# for this bug : https://bugs.debian.org/cgi-bin/bugreport.cgi?bug=619415
# seems like keepalived still hits it.. according to https://bugs.launchpad.net/kolla/+bug/1486276
# installing newer version from trusty-backports
# this won't work > node.set['keepalived']['package'] = 'keepalived/trusty-backports'
apt_package 'keepalived' do
  action :install
  default_release 'trusty-backports'
end

include_recipe 'keepalived::default'

keepalived_global_defs 'ha_global_defs' do
  router_id node.name
  enable_traps true
  notification_email node['aldebaran-haproxy']['ha']['notification_emails']
  notification_email_from "keepalived@#{node.name}"
  smtp_connect_timeout 60
end

notify_script = '/usr/local/bin/keepalived-notify.sh'
cookbook_file notify_script do
  source 'keepalived-notify.sh'
  mode '0755'
end

keepalived_vrrp_script 'chk_haproxy' do
  interval 2
  script '"pidof haproxy"'
end

## default attributes // change in case instance has 2+ interfaces
is_master = node['aldebaran-haproxy']['ha']['is_master']
node.default['aldebaran-haproxy']['ha']['unicast_src_ip'] = node['ipaddress']
node.default['aldebaran-haproxy']['ha']['interface'] = node['network']['default_interface']

keepalived_vrrp_instance 'keepalived_haproxy' do
  state is_master ? 'MASTER' : 'BACKUP'
  interface node['aldebaran-haproxy']['ha']['interface']
  virtual_router_id 50
  priority is_master ? 101 : 100
  authentication(
    auth_type: 'PASS',
    auth_pass: 'buttz' # TODO: use data bag item
  )
  unicast_src_ip node['aldebaran-haproxy']['ha']['unicast_src_ip']
  unicast_peer node['aldebaran-haproxy']['ha']['unicast_peer_ip']
  virtual_ipaddress node['aldebaran-haproxy']['ha']['virtual_ipaddress']
  track_script %w(chk_haproxy)
  notify notify_script
  smtp_alert true
end
