# 0.4.1

* Added Chef Push jobs whitelist tasks

# 0.4.0

* Refactor of SSL databag structure

# 0.1.0

* Initial release
