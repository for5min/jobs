require 'rubygems'
require 'json'
require 'chef/encrypted_data_bag_item'

if ARGV.empty?
  puts 'Need to specify path like: name/item'
  puts 'Example: If the plaintext databag is at foo/mydata_plaintext.json, enter: foo/mydata'
  exit 1
end

name = ARGV[0]
secret = Chef::EncryptedDataBagItem.load_secret('../../integration/encrypted_data_bag_secret')
data = JSON.parse(File.read("plain/#{name}.json"))
encrypted_data = Chef::EncryptedDataBagItem.encrypt_data_bag_item(data, secret)

File.open("ssl/#{name}.json", 'w') do |f|
  f.print JSON.pretty_generate(encrypted_data)
end
