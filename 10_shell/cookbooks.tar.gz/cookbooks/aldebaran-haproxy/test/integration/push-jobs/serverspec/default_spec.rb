require 'spec_helper'

describe file('/etc/chef/push-jobs-client.rb') do
  it { should exist }
  it { should be_file }
  it { should contain 'aldebaran-haproxy-reload' }
  it { should contain 'aldebaran-haproxy-restart' }
end
