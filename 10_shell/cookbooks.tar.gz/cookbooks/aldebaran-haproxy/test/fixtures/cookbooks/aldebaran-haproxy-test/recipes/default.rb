file '/etc/hosts' do
  content <<-EOF
127.0.0.1 localhost
127.0.1.1 #{node['hostname']}.localdomain #{node['hostname']}
127.0.1.2 bms1.example.com bms1
127.0.1.3 bms2.example.com bms2
127.0.1.4 bms3.example.com bms3
127.0.1.5 pcms1.example.com pcms1
127.0.1.6 pcms2.example.com pcms2
  EOF
end

include_recipe 'aldebaran-haproxy::default'
