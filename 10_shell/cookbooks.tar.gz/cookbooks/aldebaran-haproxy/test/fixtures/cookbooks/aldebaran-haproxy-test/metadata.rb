name 'aldebaran-haproxy-test'
version '0.0.1'

depends 'aldebaran-haproxy'
