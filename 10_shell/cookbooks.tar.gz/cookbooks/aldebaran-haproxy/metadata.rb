name             'aldebaran-haproxy'
maintainer       'Rakuten, Inc.'
maintainer_email 'ops@rakops.com'
license          'Apache 2.0'
description      'Installs/Configures aldebaran-haproxy'
long_description 'Installs/Configures aldebaran-haproxy'
version          '0.4.2'

depends 'haproxy', '~> 1.6.7'
depends 'keepalived', '~> 2.0.0'
depends 'sysctl'

source_url 'https://github.rakops.com/Chef/aldebaran-haproxy'
issues_url 'https://github.rakops.com/Chef/aldebaran-haproxy/issues'
