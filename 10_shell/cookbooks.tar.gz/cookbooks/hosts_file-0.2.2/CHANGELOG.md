## hosts_file cookbook CHANGELOG

This file is used to list the changes made in each version of the hosts_file cookbook.

## 0.2.2:
* Correct entry for ip6-allrouters
* adds test-kitchen and supporting repository tooling and documentation
