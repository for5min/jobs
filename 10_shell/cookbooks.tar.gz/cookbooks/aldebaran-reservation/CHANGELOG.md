# 0.4.4

* Added certificate installation for PMS API

# 0.4.0

* Centralise endpoint references, and clean up databags

# 0.1.0

Initial release of aldebaran-reservation
