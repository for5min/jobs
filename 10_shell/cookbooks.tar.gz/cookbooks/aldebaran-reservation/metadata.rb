name             'aldebaran-reservation'
maintainer       'Rakuten, Inc.'
maintainer_email 'ops@rakops.com'
license          'Apache 2.0'
description      'Installs/Configures aldebaran-reservation'
long_description 'Installs/Configures aldebaran-reservation'
version          '0.4.6'

supports 'ubuntu', '14.04'

depends 'aldebaran-app'
depends 'r-rabbitmq'

source_url 'https://github.rakops.com/Chef/aldebaran-reservation'
issues_url 'https://github.rakops.com/Chef/aldebaran-reservation/issues'
