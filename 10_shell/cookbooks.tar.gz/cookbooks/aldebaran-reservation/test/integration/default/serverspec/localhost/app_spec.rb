require 'spec_helper'

describe 'Reservation API application' do
  describe file('/opt/reservation/builds') do
    it { should exist }
    it { should be_directory }
  end

  describe file('/opt/reservation/builds/latest.jar') do
    it { should exist }
    it { should be_symlink }
  end

  describe file('/opt/reservation/config') do
    it { should exist }
    it { should be_directory }
  end

  describe file('/opt/reservation/config/app.yaml') do
    it { should exist }
    it { should be_file }
    its(:content) { should contain 'port: 8080' }
    its(:content) { should contain 'username: rmq' }
    its(:content) { should contain 'password: rmq' }
    its(:content) { should contain 'port: 5672' }
    its(:content) { should contain 'vhost: /' }
  end
end
