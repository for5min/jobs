require 'rubygems'
require 'json'
require 'chef/encrypted_data_bag_item'

secret = Chef::EncryptedDataBagItem.load_secret('../../integration/encrypted_data_bag_secret')
data = JSON.parse(File.read('rabbitmq/credentials_plaintext.json'))
encrypted_data = Chef::EncryptedDataBagItem.encrypt_data_bag_item(data, secret)

File.open('rabbitmq/credentials.json', 'w') do |f|
  f.print JSON.pretty_generate(encrypted_data)
end
