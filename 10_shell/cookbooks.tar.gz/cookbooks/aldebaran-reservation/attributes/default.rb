#
# Cookbook Name:: aldebaran-reservation
# Attributes:: default
#
# Copyright (C) 2016 Rakuten, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

default['aldebaran-reservation']['aldebaran-app']['user'] = {
  'name' => 'reservation',
  'group' => 'aldebaran'
}

default['aldebaran-reservation']['aldebaran-app']['name'] = 'reservation'

# Databags
default['aldebaran-reservation']['rabbitmq']['databag_name'] = 'rabbitmq'
default['aldebaran-reservation']['rabbitmq']['databag_item'] = 'credentials'
default['aldebaran-reservation']['pms_api_auth']['databag_name'] = node['aldebaran-reservation']['aldebaran-app']['name']
default['aldebaran-reservation']['pms_api_auth']['databag_item'] = 'pms_api_auth'

default['aldebaran-reservation']['aldebaran-app']['java_certs'] = [
  {
    'host' => 'stg-gpoint-api.stg.jp.local'
  }
]
